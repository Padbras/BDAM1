package domaine;

public final class SessionFactory {

}
