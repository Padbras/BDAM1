package domaine;

import domaine.base.BasePersonnes;



public class Personnes extends BasePersonnes {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public Personnes () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public Personnes (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}